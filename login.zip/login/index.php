<?php 
  header('location:login');
?>
